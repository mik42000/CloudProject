package fr.check;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Query;

/**
 * CheckAccount Retourne le risque d'un compte bancaire
 */
@Path("/check")
public class CheckAccount {

	// Instance du datastoreService
	private final DatastoreService datastoreService;

	/**
	 * Constructeur
	 */
	public CheckAccount() {
		this.datastoreService = DatastoreServiceFactory.getDatastoreService();
	}

	/**
	 * Retourne le risque d'un compte bancaire
	 * 
	 * @param req
	 * @param res
	 * @return String
	 */
	@GET
	@Path("/account")
	public String check(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		// res.setContentType("text/plain");
		// Obtention de l'ID de l'account grâce au paramètre "id" (GET)
		String name = req.getParameter("name");

		if (name != null && !name.equals("")) {
			Entity account = null;
			Query q = new Query("Account")
					.setFilter(new Query.FilterPredicate("nameOwner", Query.FilterOperator.EQUAL, name));

			account = this.datastoreService.prepare(q).asSingleEntity();
			if (account != null) {
				String risk = account.getProperty("risk").toString();
				return risk;
			} else {
				return "error";
			}
		}
		return "error";
	}

}