package fr.appmanager;

public class Approval {

	private String nom;

	public Approval(String nom) {
		this.nom = nom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public String toString() {
		return "Approval [nom=" + nom + "]";
	}
}
