package fr.appmanager;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Query;

/**
 * AppManager Permet d'ajouter, de lister et de supprimer des approvals
 */
@Path("/approvals")
public class AppManager {

	// Instance du datastoreService
	private final DatastoreService datastoreService;

	/**
	 * Constructeur
	 */
	public AppManager() {
		// Obtention du datastore
		this.datastoreService = DatastoreServiceFactory.getDatastoreService();
	}

	/**
	 * Permet d'ajouter un Approval
	 * 
	 * @param nom
	 */
	@POST
	@Path("/add")
	public Response addApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		res.setContentType("text/plain");
		try {
			// Obtention du nom grâce au paramètre "nom" (GET)
			final String nom = req.getParameter("nom");

			if (nom != null && !nom.equals("")) {
				// Obtention du dernier ID des approvals
				final Query q = new Query("Approval");
				final List<Entity> listApproval = this.datastoreService.prepare(q)
						.asList(FetchOptions.Builder.withDefaults());
				int lastID = 1;
				for (Entity approval : listApproval) {
					final int idTmp = (int) approval.getKey().getId();
					if (idTmp >= lastID) {
						lastID = idTmp + 1;
					}
				}

				// Création d'une entity de type Approval
				final Entity entityApproval = new Entity("Approval", lastID);
				// Affectation du nom
				entityApproval.setProperty("nom", nom);

				// Ajout de cette entity dans le datastore
				this.datastoreService.put(entityApproval);

				// Création de la réponse
				res.getWriter().println(nom + " ajouté à la liste des approvals");

				return Response.created(null).status(HttpServletResponse.SC_OK).build();
			} else {
				res.getWriter().println("Si pas de paramètre 'nom' dans la requête, le service ne peut rien ajouter");
				return Response.created(null).status(HttpServletResponse.SC_FORBIDDEN).build();
			}
		} catch (IOException e) {
			throw new WebApplicationException(404);
		}
	}

	/**
	 * Retourne la liste des Approval
	 * 
	 * @return
	 * @throws IOException
	 */
	@GET
	@Path("/all")
	@Produces("text/html")
	public Response getListOfApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		final StringBuilder sb = new StringBuilder();

		// Obtention de tous les approvals
		final Query q = new Query("Approval");
		final List<Entity> listApproval = this.datastoreService.prepare(q).asList(FetchOptions.Builder.withDefaults());

		sb.append("<p>Liste des Approvals : </p>");
		sb.append("<table style='border: 1px solid;border-collapse: collapse;'>");
		sb.append("<tbody>");
		sb.append("<tr style='border-bottom: 1px solid;'>");
		sb.append("<td>ID</td>");
		sb.append("<td>Nom</td>");
		sb.append("</tr>");
		// Pour chaque approval, on affiche son id et son nom
		for (Entity approval : listApproval) {
			final int id = (int) approval.getKey().getId();
			final String nomApprovalTmp = (String) approval.getProperty("nom");

			sb.append("<tr>");
			sb.append("<td>").append(id).append("</td>");
			sb.append("<td>").append(nomApprovalTmp).append("</td>");
			sb.append("</tr>");
		}
		sb.append("</tbody>");
		sb.append("</table>");

		// On retourne la réponse
		return Response.ok(sb.toString(), MediaType.TEXT_HTML).build();
	}

	/**
	 * Supprime un Approval
	 * 
	 * @return
	 * @throws IOException
	 */
	@GET
	@Path("/delete")
	public Response deleteApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		res.setContentType("text/plain");
		try {
			// Obtention de l'ID de l'Approval grâce au paramètre "id" (GET)
			String idStr = req.getParameter("id");

			if (idStr != null && !idStr.equals("")) {

				// On vérifie le format du paramètre "id"
				int idInt = 0;
				try {
					idInt = Integer.parseInt(idStr);
				} catch (NumberFormatException e) {
					idInt = -1;
				}

				// Si le format était correct, on supprime l'Approval
				if (idInt > -1) {
					final Key cleApproval = KeyFactory.createKey("Approval", idInt);

					// Vérification de l'existence de l'approval
					Entity entityToDelete = null;
					try {
						entityToDelete = this.datastoreService.get(cleApproval);
					} catch (EntityNotFoundException e) {
						res.getWriter().println("L'entité n'existe pas.");
						return Response.created(null).status(HttpServletResponse.SC_NOT_FOUND).build();
					}

					if (entityToDelete != null) {
						// Suppression de l'approval
						this.datastoreService.delete(cleApproval);
					}

					res.getWriter().println(idInt + " supprimé de la liste des approvals");
				} else {
					res.getWriter().println("Veuillez entrer un id d'approvals valide !");
				}
				return Response.created(null).status(HttpServletResponse.SC_OK).build();
			} else {
				res.getWriter().println("Si pas de paramètre 'id' dans la requête, le service ne peut rien supprimer");
				return Response.created(null).status(HttpServletResponse.SC_FORBIDDEN).build();
			}
		} catch (IOException e) {
			throw new WebApplicationException(404);
		}
	}

	/**
	 * Simule une réponse (acceptation ou refus) d'un humain
	 * 
	 * @return
	 * @throws IOException
	 */
	@GET
	@Path("/check")
	@Produces("text/html")
	public Response checkApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		final double rand = Math.random();

		String str;
		if (rand > 0.5) {
			str = "approved";
		} else {
			str = "refused";
		}

		// On retourne la réponse
		return Response.ok(str, MediaType.TEXT_HTML).build();
	}

	/**
	 * Retourne le dernier ID du datastore (utile pour les tests de
	 * fonctionnement)
	 * 
	 * @param req
	 * @param res
	 * @return
	 */
	@GET
	@Path("/lastId")
	public Response lastIdOfApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		final Query q = new Query("Approval");
		final List<Entity> listAccount = this.datastoreService.prepare(q).asList(FetchOptions.Builder.withDefaults());

		// Obtention du dernier ID des approvals
		int lastID = 1;
		for (Entity approval : listAccount) {
			final int idTmp = (int) approval.getKey().getId();
			if (idTmp >= lastID) {
				lastID = idTmp;
			}
		}

		return Response.ok(String.valueOf(lastID), MediaType.TEXT_PLAIN).build();
	}
}
