package fr.accmanager;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;

/**
 * AccManager
 * Permet d'ajouter, de lister et de supprimer des comptes bancaires
 */
@Path("/accounts")
public class AccManager {

	// Instance du datastoreService
	private final DatastoreService datastoreService;

	/**
	 * Constructeur
	 */
	public AccManager() {
		this.datastoreService = DatastoreServiceFactory.getDatastoreService();
	}

	/**
	 * Ajoute un approval
	 * @param req
	 * @param res
	 * @return
	 */
	@POST
	@Path("/add")
	// @Consumes(MediaType.APPLICATION_JSON)
	public Response addApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		res.setContentType("text/plain");

		try {
			final String nom = req.getParameter("nom");
			final String prenom = req.getParameter("prenom");
			final int account = Integer.parseInt(req.getParameter("account"));
			final String risk = req.getParameter("risk");

			if (nom != null && !nom.equals("") && prenom != null && !prenom.equals("") && account > 0 && risk != null
					&& !risk.equals("")) {
				final Query q = new Query("Account");
				final List<Entity> listAccount = this.datastoreService.prepare(q)
						.asList(FetchOptions.Builder.withDefaults());

				// Obtention du dernier ID des approvals
				int lastID = 1;
				for (Entity approval : listAccount) {
					final int idTmp = (int) approval.getKey().getId();
					if (idTmp >= lastID) {
						lastID = idTmp + 1;
					}
				}

				// CrÃ©ation d'une entity de type Approval
				final Entity entityApproval = new Entity("Account", lastID);
				entityApproval.setProperty("nameOwner", nom);
				entityApproval.setProperty("firstNameOwner", prenom);
				entityApproval.setProperty("account", account);
				entityApproval.setProperty("risk", risk);

				// Ajout de cette entity dans le datastore
				this.datastoreService.put(entityApproval);

				// CrÃ©ation de la rÃ©ponse res.getWriter().println()
				res.getWriter()
						.println("L'account " + account + " de " + prenom + " " + nom + " a été ajouté à la liste des accounts");

				return Response.created(null).status(HttpServletResponse.SC_OK).build();
			} else {
				res.getWriter().println("Les paramÃštres nom, prenom, account, risk sont obligatoires.");
				return Response.created(null).status(HttpServletResponse.SC_FORBIDDEN).build();
			}
		} catch (IOException e) {
			throw new WebApplicationException(404);
		}

	}

	/**
	 * Liste les approvals
	 * @return
	 */
	@GET
	@Path("/all")
	@Produces("text/html")
	public Response listAccount() {
		final StringBuilder sb = new StringBuilder();

		sb.append("<p>Liste des Accounts : </p>");
		sb.append("<table style='border: 1px solid;border-collapse: collapse;'>");
		sb.append("<tbody>");
		sb.append("<tr style='border-bottom: 1px solid;'>");
		sb.append("<td>ID</td>");
		sb.append("<td>Name Owner</td>");
		sb.append("<td>First Name Owner</td>");
		sb.append("<td>Account</td>");
		sb.append("<td>Risk</td>");
		sb.append("</tr>");
		final Query query = new Query("Account");
		final PreparedQuery pq = this.datastoreService.prepare(query);
		for (Entity result : pq.asIterable()) {
			final int id = (int) result.getKey().getId();
			final String nameOwner = (String) result.getProperty("nameOwner");
			final String firstNameOwner = (String) result.getProperty("firstNameOwner");
			final Integer account = ((Long) result.getProperty("account")).intValue();
			final String risk = (String) result.getProperty("risk");

			sb.append("<tr>");
			sb.append("<td>").append(id).append("</td>");
			sb.append("<td>").append(nameOwner).append("</td>");
			sb.append("<td>").append(firstNameOwner).append("</td>");
			sb.append("<td>").append(account).append("</td>");
			sb.append("<td>").append(risk).append("</td>");
			sb.append("</tr>");
		}
		sb.append("</tbody>");
		sb.append("</table>");
		return Response.ok(sb.toString(), MediaType.TEXT_HTML).build();
	}

	/**
	 * Supprime un approval
	 * @param req
	 * @param res
	 * @return
	 */
	@GET
	@Path("/delete")
	public Response deleteApproval(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		res.setContentType("text/plain");
		try {
			// Obtention de l'ID de l'Account grÃ¢ce au paramÃštre "id" (GET)
			String idStr = req.getParameter("id");

			if (idStr != null && !idStr.equals("")) {

				// On vÃ©rifie le format du paramÃštre "id"
				int idInt = 0;
				try {
					idInt = Integer.parseInt(idStr);
				} catch (NumberFormatException e) {
					idInt = -1;
				}

				// Si le format Ã©tait correct, on supprime l'Account
				if (idInt > -1) {
					final Key cleAccount = KeyFactory.createKey("Account", idInt);

					Entity account = null;
					try {
						account = this.datastoreService.get(cleAccount);
					} catch (EntityNotFoundException e) {
						res.getWriter().println("Account inexistant");
						return Response.created(null).status(HttpServletResponse.SC_NOT_FOUND).build();
					}

					// Suppression de l'Account
					this.datastoreService.delete(cleAccount);

					res.getWriter()
							.println("L'account " + account.getProperty("account") + " de "
									+ account.getProperty("firstNameOwner") + " " + account.getProperty("nameOwner")
									+ " a été supprimé de la liste des accounts");
				} else {
					res.getWriter().println("Veuillez entrer un id d'account valide !");
				}
				return Response.created(null).status(HttpServletResponse.SC_OK).build();
			} else {
				res.getWriter()
						.println("Si pas de paramÃštre 'id' dans la requÃšte, le service ne peut rien supprimer");
				return Response.created(null).status(HttpServletResponse.SC_FORBIDDEN).build();
			}
		} catch (IOException e) {
			throw new WebApplicationException(404);
		}
	}
	
	/**
	 * Retourne le dernier ID du datastore (utile pour les tests de fonctionnement)
	 * @param req
	 * @param res
	 * @return
	 */
	@GET
	@Path("/lastId")
	public Response lastIdOfAccount(@Context HttpServletRequest req, @Context HttpServletResponse res) {
		final Query q = new Query("Account");
		final List<Entity> listAccount = this.datastoreService.prepare(q)
				.asList(FetchOptions.Builder.withDefaults());

		// Obtention du dernier ID des approvals
		int lastID = 1;
		for (Entity approval : listAccount) {
			final int idTmp = (int) approval.getKey().getId();
			if (idTmp >= lastID) {
				lastID = idTmp;
			}
		}
		
		return Response.ok(String.valueOf(lastID), MediaType.TEXT_PLAIN).build();
	}

}