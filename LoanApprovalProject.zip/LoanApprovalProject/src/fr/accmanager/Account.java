package fr.accmanager;

/**
 * Compte bancaire
 */
public class Account {
	
	/**
	 * Nom de la personne
	 */
	private String nameOwner;
	
	/**
	 * Prénom de la personne
	 */
	private String firstNameOwer;
	
	/**
	 * Solde du compte bancaire
	 */
	private int account;
	
	/**
	 * Risque lié à la personne
	 */
	private String risk;

	/**
	 * Constructeur
	 */
	public Account(String nameOwner, String firstNameOwer, int account, String risk) {
		this.nameOwner = nameOwner;
		this.firstNameOwer = firstNameOwer;
		this.account = account;
		this.risk = risk;
	}

	public String getNameOwner() {
		return nameOwner;
	}

	public void setNameOwner(String nameOwner) {
		this.nameOwner = nameOwner;
	}

	public String getFirstNameOwer() {
		return firstNameOwer;
	}

	public void setFirstNameOwer(String firstNameOwer) {
		this.firstNameOwer = firstNameOwer;
	}

	public int getAccount() {
		return account;
	}

	public void setAccount(int account) {
		this.account = account;
	}

	public String getRisk() {
		return risk;
	}

	public void setRisk(String risk) {
		this.risk = risk;
	}
	
	

}
