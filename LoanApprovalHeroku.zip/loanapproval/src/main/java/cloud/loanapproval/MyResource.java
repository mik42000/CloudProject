package cloud.loanapproval;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("loanapproval")
public class MyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @param req
     * @param res
     * @return String that will be returned as a text/plain response.
     */
    @GET
    //@Produces(MediaType.TEXT_PLAIN)
    public Response getIt(@Context HttpServletRequest req, @Context HttpServletResponse res) {
            res.setContentType("text/plain");
            
            final String amountParam = req.getParameter("amount");
            final String name = req.getParameter("name");
            
            try {
                if(name != null && name != "" && amountParam != null && amountParam != "") {
                    final int amount = Integer.parseInt(amountParam);
                    if(amount < 10000) {
                        String response1 = ClientBuilder
                            .newClient()
                            .target("https://loanapprovalproject-42.appspot.com/CheckAccount/check/account?name="+name)
                            .request()
                            .get(String.class);
                        if(response1.equals("low")) {
                            res.getWriter().println("Demande validee. Veuillez accepter " + amount + " euros.");
                            return Response.created(null).status(200).build();
                        }
                        else if(response1.equals("high")) {
                            String response2 = ClientBuilder
                                .newClient()
                                .target("https://loanapprovalproject-42.appspot.com/AppManager/approvals/check")
                                .request()
                                .get(String.class);
                            if(response2.equals("approved")) {
                                res.getWriter().println(response2 + " -> " + "Veuillez accepter " + amount + " euros.");
                            }
                            else if(response2.equals("refused")) {
                                res.getWriter().println(response2);
                            }
                            return Response.created(null).status(200).build();
                        }
                    }
                    else if(amount >= 10000) {
                        String response2 = ClientBuilder
                            .newClient()
                            .target("https://loanapprovalproject-42.appspot.com/AppManager/approvals/check")
                            .request()
                            .get(String.class);
                        if(response2.equals("approved")) {
                            res.getWriter().println(response2 + " -> " + "Veuillez accepter " + amount + " euros.");
                        }
                        else if(response2.equals("refused")) {
                            res.getWriter().println(response2);
                        }
                        return Response.created(null).status(200).build();
                    }
                }
                else {
                    res.getWriter().println("Si pas de parametre 'name' et 'amount' dans la requete, le service ne peut pas fonctionner");
                    return Response.created(null).status(HttpServletResponse.SC_FORBIDDEN).build();
                }
            }
            catch (IOException ex) {
                throw new WebApplicationException(404);
            }
        return Response.created(null).status(200).build();
    }
}
